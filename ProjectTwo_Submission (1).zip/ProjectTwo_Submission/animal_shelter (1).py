from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        # Connection Variables
        
        USER = username
        PASS = password
        HOST = '127.0.0.1'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'
        
        # Initialize Connection
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        print("Connection Successful")

    # create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            # insert_one is used to add a document to the database
            insert_result = self.collection.insert_one(data)
            
            # Check if the insert was acknowledged by the database
            if insert_result.acknowledged:
                return True
            else:
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

            # Read method (R in CRUD)
    def read(self, search_data):
        if search_data is not None:
            # Find and return list of results
            cursor = self.collection.find(search_data)
            return list(cursor)
        else:
            # Return empty list if nothing found
            return []

    # Update method (U in CRUD)
    def update(self, query, update_data):
        if query is not None and update_data is not None:
            # Update data and return count of modified items
            result = self.collection.update_many(query, {"$set": update_data})
            return result.modified_count
        else:
            raise Exception("Query or update data is empty")

    # Delete method (D in CRUD)
    def delete(self, delete_data):
        if delete_data is not None:
            # Delete data and return count of deleted items
            result = self.collection.delete_many(delete_data)
            return result.deleted_count
        else:
            raise Exception("Data to delete is empty")